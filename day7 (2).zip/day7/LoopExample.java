package day7;

public class LoopExample {
	public static void main(String[] args) {
		/*for(int i=1;i<10;i++) {
			System.out.println(i);
		}
		for(int i=10;i>=1;i--) {
			System.out.println(i);
		}*/
		
		int count=0;
		for(int i=0;i<100;i++){
			if(i%2!=0) {
				count+=i;
			
		}
		
	}
		System.out.println(count);

}
}
