package day5;

import java.util.Scanner;

public class BasicCalculator {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your choice");
		System.out.println("1 : add\n 2 : sub\n 3 : mult\n 4 : div\n  5 : mod");
		int num1 = sc.nextInt();
		switch(num1) {
		case 1:{
		System.out.println("Enter 1st number");
		int a=sc.nextInt();
		System.out.println("Enter 2nd number");
		int b=sc.nextInt();
		System.out.println("add : "+( a+b));
		break;
		}
		case 2:{
			System.out.println("Enter 1st number");
			int a=sc.nextInt();
			System.out.println("Enter 2nd number");
			int b=sc.nextInt();
			System.out.println("sub : "+( a-b));
			break;
			}
		case 3:{
			System.out.println("Enter 1st number");
			int a=sc.nextInt();
			System.out.println("Enter 2nd number");
			int b=sc.nextInt();
			System.out.println("mult : "+( a*b));
			break;
			}
		case 4:{
			System.out.println("Enter 1st number");
			int a=sc.nextInt();
			System.out.println("Enter 2nd number");
			int b=sc.nextInt();
			System.out.println("div : "+( a/b));
			break;
			}
		case 5:{
			System.out.println("Enter 1st number");
			int a=sc.nextInt();
			System.out.println("Enter 2nd number");
			int b=sc.nextInt();
			System.out.println("mod : "+( a%b));
			break;
			}
		default :{
			System.out.println("Enter correct choice");
		}
	}
	}
	}
	
	


