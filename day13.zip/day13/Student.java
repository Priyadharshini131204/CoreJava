package day13;

public class Student {

		int id;
		String name;
		double ph;
		float fees;
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public double getPh() {
			return ph;
		}
		public void setPh(double ph) {
			this.ph = ph;
		}
		public float getFees() {
			return fees;
		}
		public void setFees(float fees) {
			this.fees = fees;
		}
		@Override
		public String toString() {
			return "Student [id=" + id + ", name=" + name + ", ph=" + ph + ", fees=" + fees + "]";
		}
		public Student() {
			
		}
		public Student(int id, String name, double ph, float fees) {
			super();
			this.id = id;
			this.name = name;
			this.ph = ph;
			this.fees = fees;
		}

	}


