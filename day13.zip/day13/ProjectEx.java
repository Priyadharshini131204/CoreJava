package day13;

	import java.util.Scanner;
	public class ProjectEx {


		public static void main(String[] args) {
			Scanner sc =new Scanner(System.in);
			Student std=null;
			boolean isTrue=true;
			System.out.println("enter the option man");
			while(isTrue) {
				System.out.println("press 1 for creating");
				System.out.println("press 2 for run");
				System.out.println("press 3 for modify");
				System.out.println("press 0 for quit");
				int key=sc.nextInt();
				if(key==1) {
					System.out.println("enter the id:");
					int id=sc.nextInt();
					sc.nextLine();
					System.out.println("enter the name");
					String name=sc.next();
					System.out.println("enter the ph no");
					double ph=sc.nextDouble();
					System.out.println("enter the fees ");
					float fees=sc.nextFloat();
					std =new Student(id,name,ph,fees);
				}
				else if(key==2){
					System.out.println(std);
				}
				else if(key ==3) {
					boolean istrue = true;
					while(istrue) {
						System.out.println("Enter any Choice : ");
						System.out.println("1 to modify id");
						System.out.println("2 to modify name");
						System.out.println("3 to modify fees");
						System.out.println("0 for Exit");
						int value = sc.nextInt();
						switch(value) {
						case 1:{
							System.out.println("Enter the modified id :");
							int a=sc.nextInt();
							
							std.setId(a);
							break;
						}case 2:{
							System.out.println("Enter the modified name :");
							sc.nextLine();
							String b=sc.nextLine();
							std.setName(b);
							break;
						}case 3:{
							System.out.println("Enter the modified fees :");
							int c = sc.nextInt();
							std.setFees(c);
							break;
						}case 0:{
							System.out.println("end");
							istrue= false;
							break;
						}default :{
							System.out.println("Enter the correct choice!");
						}
						}					

				}
				
			}
				else if(key==0) {
					System.out.println("end");
					isTrue=false;
				}
				else {
					System.out.println("enter the correct option");
				}

	}
		}
	}



