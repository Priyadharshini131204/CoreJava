package day3;

public class operators {

			public static void main(String[] args) {
				int a=12;
				int b=25;
				int c=10;
				int d=50;
				int e=5;
				int f=100;
				System.out.println("Enter the number:"+a);
				System.out.println("Enter the number:"+b);
				System.out.println("Arithmetic operator");
				System.out.println("Addition:"+(a+b));
				System.out.println("Subtraction:"+(a-b));
				System.out.println("Multiplication:"+(a*b));
				System.out.println("Division:"+(a/b));
				System.out.println("Modulus:"+(a%b));
				System.out.println();
				System.out.println("Relational operator");
				System.out.println(a+">"+b+(a>b));
				System.out.println(a+"<"+b+(a<b));
				System.out.println(a+">="+b+(a>=b));
				System.out.println(a+"<="+b+(a<=b));
				System.out.println(a+"=="+b+(a==b));
				System.out.println(a+"!="+b+(a!=b));
				System.out.println(a+">"+b+(a>b));
				System.out.println();
				System.out.println("Logical operator");
				System.out.println("("+a+" > "+c+" AND "+b+" < "+d+")"+":"+((a>c)&&(b<d)));
				System.out.println("("+a+" < "+e+" OR "+b+" > "+f+")"+":"+((a<e)||(b>f)));
				System.out.println();
				System.out.println("Assignment operator");
				System.out.println("initial value"+c);
				System.out.println("Intial value : "+c);
				System.out.println("After += :"+(c+=12));
				System.out.println("After -= :"+(c-=12));
				System.out.println("After *= :"+(c*=12));
				System.out.println("After /= :"+(c/=12));
				System.out.println("After %= :"+(c%=12));
				System.out.println();
				System.out.println("Unary Operations :");
				System.out.println("Initial value: "+a);
				System.out.println("After increment: "+(++a));
				System.out.println("After decrement: "+(--a));
				
			}

		}