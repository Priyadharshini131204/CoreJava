package day9;

	import java.util.Scanner;

	public class While {
			public static void main(String[] args) {
				boolean istrue = true;
				Scanner sc = new Scanner(System.in);
				while(true) {
					System.out.println("Select The Choice \n 1: Add. \n 2: Sub. \n 3: Mul. \n 4: Div. \n 5: Mod.");
					int key = sc.nextInt();
					switch(key) {
					case 1:{
						System.out.println("ADDITION.");
						System.out.println("Enter the 1st no: ");
						int a = sc.nextInt();
						System.out.println("Enter the 2nd no: ");
						int b= sc.nextInt();
						System.out.println("The Value is: "+(a+b));
						break;
					}case 2:{
						System.out.println("SUBRACTION.");
						System.out.println("Enter the 1st no: ");
						int c = sc.nextInt();
						System.out.println("Enter the 2nd no: ");
						int d= sc.nextInt();
						System.out.println("The Value is: "+(c-d));
						break;
					}case 3:{
						System.out.println("MULTIPLICATION.");
						System.out.println("Enter the 1st no: ");
						int e = sc.nextInt();
						System.out.println("Enter the 2nd no: ");
						int f= sc.nextInt();
						System.out.println("The Value is: "+(e*f));
						break;
					}case 4:{
						System.out.println("DIVISION.");
						System.out.println("Enter the 1st no: ");
						int g = sc.nextInt();
						System.out.println("Enter the 2nd no: ");
						int h= sc.nextInt();
						System.out.println("The Value is: "+(g/h));
						break;
					}case 5:{
						System.out.println("MODULUS.");
						System.out.println("Enter the 1st no: ");
						int i = sc.nextInt();
						System.out.println("Enter the 2nd no: ");
						int j= sc.nextInt();
						System.out.println("The Value is: "+(i%j));
						break;
					}default:{
						System.out.println("Enter correct choice.");
					}
					}
				System.out.println("\nEND OF THE PROGRAM");
				}
			}

	}

