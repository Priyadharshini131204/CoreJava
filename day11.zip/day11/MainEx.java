package day11;

import java.util.Scanner;
public class MainEx {
	

		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			EmployeeOops emp1 = new EmployeeOops();
			System.out.println("enter the employee id");
			emp1.id=sc.nextInt();
			sc.nextLine();
			System.out.println("enter the employee name ");
			emp1.name=sc.nextLine();
			System.out.println("enter the phone number");
			emp1.phoneNumber=sc.nextLong();
			System.out.println("enter the salary");
			emp1.salary=sc.nextFloat();
			emp1.display();

			EmployeeOops emp2 = new EmployeeOops();
			emp2.id=2;
			emp2.name="dharshini";
			emp2.phoneNumber=1273493045;
			emp2.salary=100000;
			emp2.display();
			
			EmployeeOops emp3 = new EmployeeOops();
			emp3.id=3;
			emp3.name="varsha";
			emp3.phoneNumber=837434783;
			emp3.salary=440000;
			emp3.display();
			
			EmployeeOops emp4 = new EmployeeOops();
			emp4.id=4;
			emp4.name="divya";
			emp4.phoneNumber=1319290434;
			emp4.salary=80000;
			emp4.display();
			
			EmployeeOops emp5 = new EmployeeOops();
			emp5.id=5;
			emp5.name="dd";
			emp5.phoneNumber=963742432;
			emp5.salary=90000;
			emp5.display();
			

	}
	}



