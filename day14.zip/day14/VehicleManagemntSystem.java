package day14;

public class VehicleManagemntSystem {
	public static void main(String[] args) {
		Vehicle v = new Vehicle();
		car c = new car();
		ElectricCar e = new ElectricCar();
		v.startEngine();
		c.drive();
		e.chargebattery();
		v.startEngine();
		bike b = new bike();
		b.kickStart();
		
	}

}
