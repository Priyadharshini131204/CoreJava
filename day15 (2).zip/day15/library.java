package day15;

public class library {
	private int bookid;
	private String bookname;
	private String authorname;
	private double price;
	library(){
		
	}
	library(int bookid,String bookname,String authorname,double price){
		this.bookid=bookid;
		this.bookname=bookname;
		this.authorname=authorname;
		this.price=price;
	}

	public int getBookid() {
		return bookid;
	}

	public void setBookid(int bookid) {
		this.bookid = bookid;
	}

	public String getBookname() {
		return bookname;
	}

	public void setBookname(String bookname) {
		this.bookname = bookname;
	}

	public String getAuthorname() {
		return authorname;
	}

	public void setAuthorname(String authorname) {
		this.authorname = authorname;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	public String toString() {
		return "BookId:"+ bookid+"\n BookName:"+ bookname+"\n Author name:"+authorname +"\nPrice: "+ price;
		
	}
}
