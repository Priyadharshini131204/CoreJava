package day15;

public class UI {
	public static void main(String[] args) {
		library lib=new library(101,"python","mega",1000.3);
		System.out.println(lib);
	}

}
