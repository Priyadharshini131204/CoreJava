package day15;
abstract  class Calculator{
	public abstract void add(int a, int b);
	public abstract void sub(int a, int b);
	public void mul(int a,int b) {
		System.out.println(a*b);
	}
}
public class AbstractionEx extends Calculator{
	public void add(int a,int b) {
		System.out.println(a+b);
	}
	public void sub(int a,int b) {
		System.out.println(a-b);
	}
	public static void main(String[] args) {
		AbstractionEx aex = new AbstractionEx();
		aex.add(10,10 );
		aex.add(10,10 );
		aex.mul(34,56 );
	}

}
