package day2;

public class world {
	public static void main(String arg[]) {
	byte age =20;
	System.out.print("My age is "+ age);
	short number =127;
	System.out.print("short number "+number);
	int salary =2300;
	System.out.print("salary" +salary);
	long phoneNO =123456789l;
	System.out.print("phoneNo" +phoneNO);
	float averagemark =25.9f;
	System.out.print("My averagemark "+averagemark);
	double salary2 =27.6;
	System.out.print("my salary2 "+salary2);
	char letter ='a';
	System.out.print("letter "+letter);
	boolean istrue = true;
	System.out.print("it is "+istrue);

}
}