package day16;

import java.util.ArrayList;

public class ArrayListEx {
	public static void main(String[] args) {
		ArrayList<Integer> a1 = new ArrayList();
		ArrayList<Integer> a2 = new ArrayList();
		a1.add(1);
		a1.add(1, 2);
		a1.add(3);
		a1.add(4);
		a2.add(10);
		a2.add(1, 9);
		a2.add(8);
		a2.add(7);
		System.out.println(a1);
		System.out.println(a2);
		a1.addAll(a2);
		System.out.println(a1);
		a1.addAll(1, a2);
		System.out.println(a1);
		a1.set(3, 6);
		System.out.println(a1);
		a1.addFirst(75);
		a1.addLast(66);
		System.out.println(a1);
		System.out.println(a1.getClass());
		System.out.println(a1.getFirst());
		System.out.println(a1.getLast());
		a1.remove(1);
		System.out.println(a1);
		a1.remove(a2);
		System.out.println(a2);
		a1.removeAll(a2);
		System.out.println(a1);
		a1.removeFirst();
		System.out.println(a1);
		a1.removeLast();
		System.out.println(a1);
		a2.clear();
		System.out.println(a2);
		System.out.println(a2.size());
		System.out.println(a1.indexOf(2));
		Integer[] arr = a1.toArray(new Integer[a1.size()]);
		a1.forEach(s -> System.out.println(s));
		for(int i=0;i<=a1.size()-1;i++) {
			System.out.println(arr[i]);
		}
		
		
	}

}
